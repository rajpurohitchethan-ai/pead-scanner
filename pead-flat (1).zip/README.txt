FLAT LAYOUT - upload every file here directly to the repo root (no folders).
Then: Add file > Create new file > name: .github/workflows/scan.yml > paste contents of scan.yml.txt > Commit.
Settings > Pages > Deploy from a branch > main > / (root) > Save.
Actions > PEAD scan > Run workflow.
